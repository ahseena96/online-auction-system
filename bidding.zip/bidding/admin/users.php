<?php 

?>
<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body style="background-image: url('userpage.jpg'); background-repeat: no-repeat;background-size: cover;">


<div class="container-fluid" style="border-color: black;">
	
	<div class="row" style="border-color: black;">
	<div class="col-lg-12" style="border-color: black;">
			<button class="btn btn-primary float-right btn-sm" id="new_user"><i class="fa fa-plus"></i> New user</button>
	</div>
	</div>
	<br>
	<div class="row" style="border-color: black; background-color: blanchedalmond;">
		<div class="card col-lg-12" style="border-color: black;">
			<div class="card-body" style="border-color: black;">
				<table class="table-striped table-bordered col-md-12"style="border-color: black;">
			<thead style="border-color: black;">
				<tr style="border-color: black;">
					<th class="text-center" style="border-color: black;">#</th>
					<th class="text-center" style="border-color: black;">Name</th>
					<th class="text-center" style="border-color: black;">Username</th>
					<th class="text-center" style="border-color: black;">Type</th>
					<th class="text-center" style="border-color: black;">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
 					include 'db_connect.php';
 					$type = array("","Admin","Staff","Alumnus/Alumna");
 					$users = $conn->query("SELECT * FROM users order by name asc");
 					$i = 1;
 					while($row= $users->fetch_assoc()):
				 ?>
				 <tr style="border-color: black;">
				 	<td class="text-center" style="border-color: black;">
				 		<?php echo $i++ ?>
				 	</td>
				 	<td style="border-color: black;">
				 		<?php echo ucwords($row['name']) ?>
				 	</td>
				 	
				 	<td style="border-color: black;">
				 		<?php echo $row['username'] ?>
				 	</td>
				 	<td style="border-color: black;">
				 		<?php echo $type[$row['type']] ?>
				 	</td>
				 	<td style="border-color: black;">
				 		<center>
								<div class="btn-group">
								  <button type="button" class="btn btn-primary" style="border-color: black;">Action</button>
								  <button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border-color: black;">
								    <span class="sr-only">Toggle Dropdown</span>
								  </button>
								  <div class="dropdown-menu">
								    <a class="dropdown-item edit_user" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Edit</a>
								    <div class="dropdown-divider"></div>
								    <a class="dropdown-item delete_user" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Delete</a>
								  </div>
								</div>
								</center>
				 	</td>
				 </tr>
				<?php endwhile; ?>
			</tbody>
		</table>
			</div>
		</div>
	</div>

</div>
<script>
	$('table').dataTable();
$('#new_user').click(function(){
	uni_modal('New User','manage_user.php')
})
$('.edit_user').click(function(){
	uni_modal('Edit User','manage_user.php?id='+$(this).attr('data-id'))
})
$('.delete_user').click(function(){
		_conf("Are you sure to delete this user?","delete_user",[$(this).attr('data-id')])
	})
	function delete_user($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_user',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>
</body>
</html>
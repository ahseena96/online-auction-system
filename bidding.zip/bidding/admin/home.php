<?php include 'db_connect.php'
  
 ?>
 <!DOCTYPE html>
 <html>
 <head>
<style>
   span.float-right.summary_icon {
    font-size: 3rem;
    position: absolute;
    right: 1rem;
    color: #ffffff96;
}
.imgs{
		margin: .5em;
		max-width: calc(100%);
		max-height: calc(100%);
	}
	.imgs img{
		max-width: calc(100%);
		max-height: calc(100%);
		cursor: pointer;
	}
	#imagesCarousel,#imagesCarousel .carousel-inner,#imagesCarousel .carousel-item{
		height: 60vh !important;background: black;
	}
	#imagesCarousel .carousel-item.active{
		display: flex !important;
	}
	#imagesCarousel .carousel-item-next{
		display: flex !important;
	}
	#imagesCarousel .carousel-item img{
		margin: auto;
	}
	#imagesCarousel img{
		width: auto!important;
		height: auto!important;
		max-height: calc(100%)!important;
		max-width: calc(100%)!important;
	}
    body
    {
        background-image: url(background_4.jpg);
        background-repeat: no-repeat;

        background-size: cover;
        height: 80%;
        

    }
</style>
</head>
<body>
<!--<div class="container-fluid">
    <div class="row mt-3 ml-3 mr-3">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <?php echo "Welcome, We help auctioneers and bidders connect. Every day we receive thousands of visitors to our website through our combined online and offline marketing efforts. Our goal is to help buyers find the equipment they need and help auctioneers acquire targeted bidders to their auctions.". $_SESSION['login_name']."!"  ?>
                    <hr>
                </div>
            </div>                  
        </div>
    </div>
</div>-->

<!--<body style="background-image:url(homepage.jpg);width: 10px;">-->
<div>
<h4 style="color: black; font-weight: 10px; font-style: oblique;">
Hi there! Welcome to our auction site. Please find the various options on the left side to help you understand about the system and start an auction. Inorder to create a category/delete, or view the list of categories, go to "Categories".If you would like to create a product/delete or view the list of products, go to "Products".If you would like to view the bid history, go to "Bids". In order to view the list of users, go to "Users".
</h3></div>
<script>
	$('#manage-records').submit(function(e){
        e.preventDefault()
        start_load()
        $.ajax({
            url:'ajax.php?action=save_track',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success:function(resp){
                resp=JSON.parse(resp)
                if(resp.status==1){
                    alert_toast("Data successfully saved",'success')
                    setTimeout(function(){
                        location.reload()
                    },800)

                }
                
            }
        })
    })
    $('#tracking_id').on('keypress',function(e){
        if(e.which == 13){
            get_person()
        }
    })
    $('#check').on('click',function(e){
            get_person()
    })
    function get_person(){
            start_load()
        $.ajax({
                url:'ajax.php?action=get_pdetails',
                method:"POST",
                data:{tracking_id : $('#tracking_id').val()},
                success:function(resp){
                    if(resp){
                        resp = JSON.parse(resp)
                        if(resp.status == 1){
                            $('#name').html(resp.name)
                            $('#address').html(resp.address)
                            $('[name="person_id"]').val(resp.id)
                            $('#details').show()
                            end_load()

                        }else if(resp.status == 2){
                            alert_toast("Unknow tracking id.",'danger');
                            end_load();
                        }
                    }
                }
            })
    }
</script>
</body>
</html>